#ifndef PROTOTYPES
#define PROTOTYPES

#include <memory>

std::unique_ptr<char[]> deleteRepeats(char arr[], int& removed);

#endif

