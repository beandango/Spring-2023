#ifndef MYLIBRARY_HPP
#define MYLIBRARY_HPP

#include "MyDataStructure.hpp"

namespace CS2
{
    double averageGPA(Student students[], int studentNumber);
}

#endif