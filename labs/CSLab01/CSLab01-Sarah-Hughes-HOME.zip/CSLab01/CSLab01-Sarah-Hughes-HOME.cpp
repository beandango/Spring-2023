#include <iostream>

int main()
{
    std::cout<<"Hello World from Sarah Hughes\n";

    return 0;
}