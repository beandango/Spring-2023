#ifndef TAX_HPP
#define TAX_HPP

#include "TaxDataType.hpp"
#include <vector>

void taxTake(std::vector<taxInfo>&, taxInfo&);
void printTax(std::vector<taxInfo>&, taxInfo&);
bool isValid(float&);

#endif
