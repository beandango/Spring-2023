#ifndef TAXDATATYPES_HPP
#define TAXDATATYPES_HPP

struct taxInfo
{
    float rate;
    float income;
    float taxes;
};

#endif
